import pygame
from support import import_folder


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 10
        self.image = import_folder('../graphics/bullet')[0]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.direction = direction
        