import pygame
import sys
from settings import *
from level import Level
from game_data import level_0
from ui import UI


class Game:
    def __init__(self):

        # интерфейс пользователя
        self.ui = UI(screen)

    def run(self):
        self.ui.show_health(level.cur_health, level.max_health)
        self.ui.show_coins(level.coins)


# Создаем экран
pygame.init()
screen = pygame.display.set_mode((screen_width, screen_height))

clock = pygame.time.Clock()  # Это часы на будущее, чтобы регулировать смену кадров движения привидения
level = Level(level_0, screen, 1, 1)
game = Game()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill('grey')
    level.run()
    game.run()

    pygame.display.update()
    clock.tick(60)  # указываем количество фреймов за 1 сек, т.е. количество раз, которое проиграется цикл за 1 сек
