<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="enemies" tilewidth="234" tileheight="192" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="104" height="88" source="../../graphics/enemies/enemy_land_left2.png"/>
 </tile>
 <tile id="1">
  <image width="63" height="64" source="../../graphics/enemies/enemy_setup_tile.png"/>
 </tile>
 <tile id="2">
  <image width="98" height="143" source="../../graphics/enemies/enemy_sky_left1.png"/>
 </tile>
 <tile id="3">
  <image width="234" height="192" source="../../graphics/enemies/mushroom2.png"/>
 </tile>
 <tile id="4">
  <image width="68" height="61" source="../../graphics/enemies/runner_left_2.png"/>
 </tile>
</tileset>
